#include <stdio.h>
#include <stdlib.h>
#include <string.h>



//****************************************************************************
int WriteFontH(const char *filename_in, const char *filename_out)
{
  unsigned long bfOffBits;
  long w, h;
  unsigned short biBitCount;

  int error = 1, n = 0, align, x, y, i, ch;
  FILE *in = 0, *out = 0;
  unsigned char *data = 0;
  char string[16];

  in = fopen(filename_in, "rb"); if (in == 0) goto done;
  out = fopen(filename_out, "w"); if (out == 0) goto done;

  fseek(in, 10, SEEK_SET); if (fread(&bfOffBits,  4, 1, in) != 1) goto done;
  fseek(in, 18, SEEK_SET); if (fread(&w,          4, 1, in) != 1) goto done;
  fseek(in, 22, SEEK_SET); if (fread(&h,          4, 1, in) != 1) goto done;
  fseek(in, 28, SEEK_SET); if (fread(&biBitCount, 2, 1, in) != 1) goto done;

  if (biBitCount != 24) goto done;

  data = (unsigned char *)malloc(w*h); if (data == 0) goto done;

  fseek(in, bfOffBits, SEEK_SET);
  for (y=0; y<h; y++)
  {
    for (x=0; x<w; x++)
    {
      ch = fgetc(in); if (ch == EOF) goto done;
      ch = fgetc(in); if (ch == EOF) goto done;
      ch = fgetc(in); if (ch == EOF) goto done;

      data[w*(h-1-y)+x] = ch;
    }

    align = 3*w; while (align&3) {if (fgetc(in) == EOF) goto done; align++;}
  }

  if (fprintf(out, "const unsigned char FontData[%i] =\n{\n  ", (int)(4*w*h)) < 0) goto done;

  for (y=0; y<h; y++)
  for (x=0; x<w; x++)
  for (i=0; i<4; i++)
  {
    sprintf(string, "%i", data[w*y+x]);
    if (x == w-1 && y == h-1 && i == 3) strcat(string, "\n};\n");
    else
    {
      strcat(string, ",");
      n += strlen(string); if (n >= 100) {n = 0; strcat(string, "\n  ");}
    }

    if (fprintf(out, string) < 0) goto done;
  }

  error = 0;

done:
  if (data) free(data);
  if (out) fclose(out);
  if (in) fclose(in);

  return error;
}
//****************************************************************************



//############################################################################
int main(int argc, char **argv)
{
  return WriteFontH("font.bmp", "font.h");
}
//############################################################################
