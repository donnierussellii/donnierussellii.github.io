#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>



//****************************************************************************
#define CHAR_W  16
#define CHAR_H  24

#define START_FONT_CHAR  32
#define NUM_FONT_CHARS  (126-32+1)

#define FONT_NAME  "Consolas"



#define BMP_W  (CHAR_W*NUM_FONT_CHARS)
#define BMP_H  CHAR_H



unsigned char *bmp = 0;



int SaveBMP(void)
{
  int error = 1, n, i; long i4; short i2;
  FILE *out = 0;

  out = fopen("font.bmp", "wb"); if (out == 0) goto done;

  n = 3*BMP_W; while (n&3) n++;
  n *= BMP_H;

  if (fputc('B', out) == EOF) goto done;
  if (fputc('M', out) == EOF) goto done;

  i4 = 14+40+n; if (fwrite(&i4, 4, 1, out) != 1) goto done;
  i4 = 0;       if (fwrite(&i4, 4, 1, out) != 1) goto done;
  i4 = 14+40;   if (fwrite(&i4, 4, 1, out) != 1) goto done;
  i4 = 40;      if (fwrite(&i4, 4, 1, out) != 1) goto done;
  i4 = BMP_W;   if (fwrite(&i4, 4, 1, out) != 1) goto done;
  i4 = BMP_H;   if (fwrite(&i4, 4, 1, out) != 1) goto done;
  i2 = 1;       if (fwrite(&i2, 2, 1, out) != 1) goto done;
  i2 = 24;      if (fwrite(&i2, 2, 1, out) != 1) goto done;

  for (i=0; i<4*6; i++) if (fputc(0, out) == EOF) goto done;

  for (i=0; i<BMP_H; i++)
  {
    if (fwrite(bmp + 3*BMP_W*i, 3*BMP_W, 1, out) != 1) goto done;

    n = 3*BMP_W; while (n&3) {if (fputc(0, out) == EOF) goto done; n++;}
  }

  error = 0;

done:

  if (out) fclose(out);

  return error;
}



void PutPixel(int ch, int x, int y, int r, int g, int b)
{
  if (x >= 0 && x < CHAR_W && y >= 0 && y < CHAR_H)
  {
    unsigned char *p = bmp + 3*BMP_W*(BMP_H-1-y) + 3*CHAR_W*(ch-START_FONT_CHAR) + 3*x;

    p[0] = r;
    p[1] = g;
    p[2] = b;
  }
}
//****************************************************************************



//****************************************************************************
#define CLIENTW  128
#define CLIENTH  128

#define MYCLASSNAME  "BuildFontsClass"
#define MYTITLE      "BuildFonts"



HINSTANCE hInstance = 0;
HWND hWnd = 0;
HDC hDC = 0;



LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  return DefWindowProc(hWnd, uMsg, wParam, lParam);
}



void ShutdownInterface(void)
{
  if (hWnd)
  {
    if (hDC) {ReleaseDC(hWnd, hDC); hDC = 0;}

    DestroyWindow(hWnd); hWnd = 0;
  }

  if (hInstance) {UnregisterClass(MYCLASSNAME, hInstance); hInstance = 0;}
}



void InitInterface(void)
{
  DWORD dwStyle = WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;
  DWORD dwExStyle = WS_EX_CLIENTEDGE;

  atexit(ShutdownInterface);

  hInstance = GetModuleHandle(0);

  {
    WNDCLASS wc;

    wc.style = CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
    wc.lpfnWndProc = (WNDPROC)WndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(0, IDI_APPLICATION);
    wc.hCursor = LoadCursor(0, IDC_ARROW);
    wc.hbrBackground = 0;
    wc.lpszMenuName = 0;
    wc.lpszClassName = MYCLASSNAME;
    if (!RegisterClass(&wc)) exit(1);
  }

  hWnd = CreateWindowEx(dwExStyle, MYCLASSNAME, MYTITLE, dwStyle, 0, 0, 0, 0, 0, 0, hInstance, 0); if (!hWnd) exit(1);

  hDC = GetDC(hWnd); if (!hDC) exit(1);

  {
    RECT r;
    int ax, ay, bx, by;

    r.left = 0; r.right = CLIENTW; r.top = 0; r.bottom = CLIENTH;
    AdjustWindowRectEx(&r, dwStyle, 0, dwExStyle); ax = r.right-r.left; ay = r.bottom-r.top;
    SystemParametersInfo(SPI_GETWORKAREA, 0, &r, 0); bx = r.right-r.left; by = r.bottom-r.top;
    MoveWindow(hWnd, (bx-ax)/2, (by-ay)/2, ax, ay, 1);
    ShowWindow(hWnd, SW_SHOW);
  }
}
//****************************************************************************



//****************************************************************************
int BuildFont(void)
{
  int error = 1, ch;
  HFONT font = 0, oldfont;

  bmp = (unsigned char *)malloc(3*BMP_W*BMP_H); if (bmp == 0) goto done;
  memset(bmp, 0, 3*BMP_W*BMP_H);

  font = CreateFont(-CHAR_H, CHAR_W, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET,
                    OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, DEFAULT_PITCH,
                    FONT_NAME); if (font == 0) goto done;

  SetBkMode(hDC, OPAQUE);
  SetBkColor(hDC, RGB(0,0,0));
  SetTextColor(hDC, RGB(255,255,255));

  for (ch=START_FONT_CHAR; ch<START_FONT_CHAR+NUM_FONT_CHARS; ch++)
  {
    char text[1];
    SIZE s;
    int w, h, ox, oy, x, y;

    text[0] = ch;
    oldfont = (HFONT)SelectObject(hDC, font);
    GetTextExtentPoint32(hDC, text, 1, &s);
    TextOut(hDC, 0, 0, text, 1);
    SelectObject(hDC, oldfont);

    w = s.cx; ox = (CHAR_W-w)/2;
    h = s.cy; oy = (CHAR_H-h)/2 - ((ch < 32 || ch >= 127) ? 0 : 3);

    for (y=0; y<h; y++)
    for (x=0; x<w; x++)
    {
      COLORREF c = GetPixel(hDC, x, y);

      PutPixel(ch, x+ox, y+oy, GetRValue(c), GetGValue(c), GetBValue(c));
    }
  }

  if (SaveBMP() == 0) goto done;

  error = 0;

done:

  if (font) DeleteObject(font);
  if (bmp) free(bmp);

  return error;
}
//****************************************************************************



//############################################################################
int main(int argc, char **argv)
{
  InitInterface();
  return BuildFont();
}
//############################################################################
