#include <stdlib.h>
#include <stdio.h>
#include <string.h>



//****************************************************************************
int WriteWhitelist(void)
{
  FILE *in = 0, *out = 0;
  char *data = 0, *p, *q;
  int size, error = 1;
  const char *string = "EMTERPRETIFY_WHITELIST=\'";

  in = fopen("log.txt", "rb"); if (in == 0) goto done;
  out = fopen("whitelist.json", "wb"); if (out == 0) goto done;

  fseek(in, 0, SEEK_END);
  size = ftell(in);
  fseek(in, 0, SEEK_SET);
  data = (char *)malloc(size); if (data == 0) goto done;
  if (fread(data, 1, size, in) != size) goto done;
  p = strstr(data, string); if (p == 0) goto done;
  p += strlen(string);
  q = strstr(p, "]"); if (q == 0) goto done;
  size = q+1-p;
  if (fwrite(p, 1, size, out) != size) goto done;

  error = 0;

done:
  if (data) free(data);
  if (out) fclose(out);
  if (in) fclose(in);

  return error;
}
//****************************************************************************



//############################################################################
int main(void)
{
  if (WriteWhitelist() == 0) printf("whitelist.json written\n");

  return 0;
}
//############################################################################
