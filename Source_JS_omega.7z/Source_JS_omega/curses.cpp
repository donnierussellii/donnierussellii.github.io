#include <stdio.h> //vsprintf
#include <stdarg.h> //va_list va_start vsprintf va_end



#define PUTSD(ch) \
  { if (win->cx >= 0 && win->cx < win->w && win->cy >= 0 && win->cy < win->h) \
      win->data[80*(win->y + win->cy) + (win->x + win->cx)] = (ch); }

#define GETSD \
  { if (win->cx >= 0 && win->cx < win->w && win->cy >= 0 && win->cy < win->h) \
      ch = win->data[80*(win->y + win->cy) + (win->x + win->cx)]; }

#define PUTCUR(h)  {PutCursor(curscr->cx, curscr->cy, (h));}

typedef struct WINDOW_STRUCT {int w, h, x, y, cx, cy, a; char m; unsigned short data[80*24];} WINDOW;

#define MAX_WINDOWS  32

WINDOW WinList[MAX_WINDOWS], *curscr, *stdscr;

int WinIndex;

#define DEFAULT_ATTR  15 //bright white



//from os.cpp
void Render(void);
void SleepMS(unsigned int ms);
int GetInput(unsigned int ms);
void PutFont(int ch, int x, int y);
void PutCursor(int x, int y, int h);



//****************************************************************************
WINDOW *initscr(void)
{
  int i;

  WinIndex = 0;

  curscr = &WinList[WinIndex++];
  curscr->w  = 80;
  curscr->h  = 24;
  curscr->x  = 0;
  curscr->y  = 0;
  curscr->cx = 0;
  curscr->cy = 0;
  curscr->a  = DEFAULT_ATTR;
  curscr->m  = 0;
  for (i=0; i<80*24; i++) curscr->data[i] = ' ';

  stdscr = &WinList[WinIndex++];
  stdscr->w  = 80;
  stdscr->h  = 24;
  stdscr->x  = 0;
  stdscr->y  = 0;
  stdscr->cx = 0;
  stdscr->cy = 0;
  stdscr->a  = DEFAULT_ATTR;
  stdscr->m  = 0;
  for (i=0; i<80*24; i++) stdscr->data[i] = ' ';

  return stdscr;
}

WINDOW *newwin(int h, int w, int y, int x)
{
  WINDOW *win;
  int i;

  if (WinIndex == MAX_WINDOWS) {} //out of window space

  win = &WinList[WinIndex++];
  win->w  = !w ? 80-x : w;
  win->h  = !h ? 24-y : h;
  win->x  = x;
  win->y  = y;
  win->cx = 0;
  win->cy = 0;
  win->a  = DEFAULT_ATTR;
  win->m  = 0;
  for (i=0; i<80*24; i++) win->data[i] = ' ';

  return win;
}


int endwin(void) {return 0;}


int wclear(WINDOW *win)
{
  int i, j;

  for (j=win->y; j<win->y + win->h; j++)
  for (i=win->x; i<win->x + win->w; i++)
    win->data[80*j+i] = ' ';

  win->cx = 0;
  win->cy = 0;
  return 0;
}

int clear(void) {return wclear(stdscr);}


int wmove(WINDOW *win, int y, int x)
{
  win->cx = x;
  win->cy = y;
  return 0;
}

int move(int y, int x) {return wmove(stdscr, y, x);}


int getcurx(WINDOW *win) {return win->cx;}
int getcury(WINDOW *win) {return win->cy;}


int wattrset(WINDOW *win, int a)
{
  win->a = a;
  return 0;
}

int wstandout(WINDOW *win)
{
  win->a = DEFAULT_ATTR << 4;
  return 0;
}

int standout(void) {return wstandout(stdscr);}

int wstandend(WINDOW *win)
{
  win->a = DEFAULT_ATTR;
  return 0;
}

int standend(void) {return wstandend(stdscr);}


int winch(WINDOW *win)
{
  int ch = 0;

  GETSD
  return ch;
}


int waddch(WINDOW *win, const int ch)
{
  if (ch == '\n')
  {
    for (; win->cx < win->w; win->cx++) PUTSD(' ')
    win->cx = 0;
    win->cy++; if (win->cy > win->h-1) {}
  }
  else if (ch == '\b')
  {
    if (win->cx > 0)
    {
      win->cx--;
      PUTSD(' ')
    }
  }
  else if (ch == '\t')
  {
    int n = 8 - (win->cx % 8);

    while (n-- > 0)
    {
      PUTSD(' ')
      win->cx++;
      if (win->cx > win->w-1)
      {
        win->cx = 0;
        win->cy++; if (win->cy > win->h-1) {}
      }
    }
  }
  else
  {
    PUTSD(ch | (win->a << 8))
    win->cx++;
    if (win->cx > win->w-1)
    {
      win->cx = 0;
      win->cy++; if (win->cy > win->h-1) {}
    }
  }

  return 0;
}

int waddstr(WINDOW *win, const char *p)
{
  while (*p) waddch(win, *p++);
  return 0;
}

int wprintw(WINDOW *win, const char *fmt, ...)
{
  char buf[256];
  va_list args;

  va_start(args, fmt);
  vsprintf(buf, fmt, args);
  va_end(args);

  return waddstr(win, buf);
}

int printw(const char *fmt, ...)
{
  char buf[256];
  va_list args;

  va_start(args, fmt);
  vsprintf(buf, fmt, args);
  va_end(args);

  return waddstr(stdscr, buf);
}


int wrefresh(WINDOW *win)
{
  int i, j;

  curscr->cx = win->x + win->cx;
  curscr->cy = win->y + win->cy;

  for (j=win->y; j<win->y + win->h; j++)
  for (i=win->x; i<win->x + win->w; i++)
  if (curscr->data[80*j+i] != win->data[80*j+i])
  {
    win->m = 1;
    curscr->data[80*j+i] = win->data[80*j+i];
    PutFont(curscr->data[80*j+i], i, j);
  }

  return 0;
}

int refresh(void) {return wrefresh(stdscr);}


int wgetch(WINDOW *win __attribute__((unused)))
{
  int i = 0, ch;

  for (;;)
  {
    if (i == 0 || i == 16/2) {PUTCUR(3)  Render();}

    ch = GetInput(40);
    if (ch == '\r') ch = '\n';
    if (ch) break;

    i = (i + 1) % 16;
  }
  if (i < 16/2) PUTCUR(3)

  return ch;
}

int getch(void) {return wgetch(stdscr);}
//****************************************************************************



//****************************************************************************
int tick_pause(int ms)
{
  Render();
  return GetInput(ms);
}



int was_screen_modified_except(WINDOW *except)
{
  int i, flag = 0;

  for (i=0; i<WinIndex; i++)
    if (&WinList[i] != curscr && &WinList[i] != except)
      if (WinList[i].m) {WinList[i].m = 0; flag = 1;}

  return flag;
}



void os_message(const char *p)
{
  int x = 0;

  while (*p && x < 80) PutFont((short)(*p++)|(15<<8), x++, 0);
  Render();
  SleepMS(0);
}
//****************************************************************************
