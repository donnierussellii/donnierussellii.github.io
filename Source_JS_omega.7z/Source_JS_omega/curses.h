#define KEY_UP_LEFT           (128+0)
#define KEY_UP                (128+1)
#define KEY_UP_RIGHT          (128+2)
#define KEY_LEFT              (128+3)
#define KEY_RIGHT             (128+4)
#define KEY_DOWN_LEFT         (128+5)
#define KEY_DOWN              (128+6)
#define KEY_DOWN_RIGHT        (128+7)

#define KEY_SHIFT_UP_LEFT     (128+8+0)
#define KEY_SHIFT_UP          (128+8+1)
#define KEY_SHIFT_UP_RIGHT    (128+8+2)
#define KEY_SHIFT_LEFT        (128+8+3)
#define KEY_SHIFT_RIGHT       (128+8+4)
#define KEY_SHIFT_DOWN_LEFT   (128+8+5)
#define KEY_SHIFT_DOWN        (128+8+6)
#define KEY_SHIFT_DOWN_RIGHT  (128+8+7)

#define getyx(win,y,x)  (y = getcury(win), x = getcurx(win))

typedef struct WINDOW_STRUCT {int w, h, x, y, cx, cy, a; char m; unsigned short data[80*24];} WINDOW;

extern WINDOW *stdscr;
extern WINDOW *curscr;

WINDOW *initscr(void);
WINDOW *newwin(int h, int w, int y, int x);
int endwin(void);
int wclear(WINDOW *win);
int clear(void);
int wmove(WINDOW *win, int y, int x);
int move(int y, int x);
int getcurx(WINDOW *win);
int getcury(WINDOW *win);
int wattrset(WINDOW *win, int a);
int wstandout(WINDOW *win);
int standout(void);
int wstandend(WINDOW *win);
int standend(void);
int winch(WINDOW *win);
int waddch(WINDOW *win, const int ch);
int waddstr(WINDOW *win, const char *p);
int wprintw(WINDOW *win, const char *fmt, ...);
int printw(const char *fmt, ...);
int wrefresh(WINDOW *win);
int refresh(void);
int wgetch(WINDOW *win);
int getch(void);

int tick_pause(int ms);
int was_screen_modified_except(WINDOW *except);
void os_message(const char *p);
