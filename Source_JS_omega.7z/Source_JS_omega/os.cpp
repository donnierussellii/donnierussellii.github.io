//............................................................................
#ifdef COMPILE_WIN
  #define WIN32_LEAN_AND_MEAN
  #include <windows.h>
#endif

#include <SDL2/SDL.h>

#ifndef COMPILE_SDL
  #include <emscripten.h>
#else
  #include <stdlib.h>
#endif

#include "font/font.h"



#define CHAR_W  16
#define CHAR_H  24

#define CLIENT_W  (CHAR_W * 80)
#define CLIENT_H  (CHAR_H * 24)

#define NUM_FONT_CHARS  (126-32+1)

#define MY_WINDOW_TITLE  "SDLomega"



SDL_Window *MyWindow;
SDL_Renderer *MyRenderer;
SDL_Texture *MyBackTexture, *MyFontTexture;
//............................................................................



//****************************************************************************
#ifndef COMPILE_SDL

void IDBFS_init(void)
{
  EM_ASM (
    FS.mkdir('/omega');
    FS.mount(IDBFS, {}, '/omega');
    FS.syncfs(true, function(err){assert(!err);});
  );
}
              
              

void IDBFS_sync(void)
{
  EM_ASM (
    FS.syncfs(function(err){assert(!err);});
  );
}

#endif
//****************************************************************************



//****************************************************************************
void GetMyRenderDest(SDL_Rect *dest)
{
  int w, h, w2, h2;

  SDL_GetWindowSize(MyWindow, &w, &h);

  if ((double)w/CLIENT_W < (double)h/CLIENT_H) {w2 = w; h2 = w*CLIENT_H/CLIENT_W;}
  else                                         {h2 = h; w2 = h*CLIENT_W/CLIENT_H;}

  dest->x = (w-w2)/2;
  dest->y = (h-h2)/2;
  dest->w = w2;
  dest->h = h2;
}
//****************************************************************************



//****************************************************************************
int InputRoutine(int sym, int shift)
{
  int o = (shift ? -32 : 0);
  int o2 = 128 + (shift ?  8 : 0);

  switch (sym)
  {
    case SDLK_BACKSPACE: return   8;
    case SDLK_TAB      : return   9;
    case SDLK_RETURN   : return  13;
    case SDLK_ESCAPE   : return  27;
    case SDLK_SPACE    : return  32;
    case SDLK_DELETE   : return 127;

    case SDLK_BACKQUOTE   : return shift ?  '~' :  '`';
    case SDLK_1           : return shift ?  '!' :  '1';
    case SDLK_2           : return shift ?  '@' :  '2';
    case SDLK_3           : return shift ?  '#' :  '3';
    case SDLK_4           : return shift ?  '$' :  '4';
    case SDLK_5           : return shift ?  '%' :  '5';
    case SDLK_6           : return shift ?  '^' :  '6';
    case SDLK_7           : return shift ?  '&' :  '7';
    case SDLK_8           : return shift ?  '*' :  '8';
    case SDLK_9           : return shift ?  '(' :  '9';
    case SDLK_0           : return shift ?  ')' :  '0';
    case SDLK_MINUS       : return shift ?  '_' :  '-';
    case SDLK_EQUALS      : return shift ?  '+' :  '=';
    case SDLK_LEFTBRACKET : return shift ?  '{' :  '[';
    case SDLK_RIGHTBRACKET: return shift ?  '}' :  ']';
    case SDLK_BACKSLASH   : return shift ?  '|' : '\\';
    case SDLK_SEMICOLON   : return shift ?  ':' :  ';';
    case SDLK_QUOTE       : return shift ? '\"' : '\'';
    case SDLK_COMMA       : return shift ?  '<' :  ',';
    case SDLK_PERIOD      : return shift ?  '>' :  '.';
    case SDLK_SLASH       : return shift ?  '?' :  '/';

    case SDLK_a: return 'a' + o;
    case SDLK_b: return 'b' + o;
    case SDLK_c: return 'c' + o;
    case SDLK_d: return 'd' + o;
    case SDLK_e: return 'e' + o;
    case SDLK_f: return 'f' + o;
    case SDLK_g: return 'g' + o;
    case SDLK_h: return 'h' + o;
    case SDLK_i: return 'i' + o;
    case SDLK_j: return 'j' + o;
    case SDLK_k: return 'k' + o;
    case SDLK_l: return 'l' + o;
    case SDLK_m: return 'm' + o;
    case SDLK_n: return 'n' + o;
    case SDLK_o: return 'o' + o;
    case SDLK_p: return 'p' + o;
    case SDLK_q: return 'q' + o;
    case SDLK_r: return 'r' + o;
    case SDLK_s: return 's' + o;
    case SDLK_t: return 't' + o;
    case SDLK_u: return 'u' + o;
    case SDLK_v: return 'v' + o;
    case SDLK_w: return 'w' + o;
    case SDLK_x: return 'x' + o;
    case SDLK_y: return 'y' + o;
    case SDLK_z: return 'z' + o;

    case SDLK_HOME    : case SDLK_KP_7: return o2 + 0;
    case SDLK_UP      : case SDLK_KP_8: return o2 + 1;
    case SDLK_PAGEUP  : case SDLK_KP_9: return o2 + 2;
    case SDLK_LEFT    : case SDLK_KP_4: return o2 + 3;
    case SDLK_RIGHT   : case SDLK_KP_6: return o2 + 4;
    case SDLK_END     : case SDLK_KP_1: return o2 + 5;
    case SDLK_DOWN    : case SDLK_KP_2: return o2 + 6;
    case SDLK_PAGEDOWN: case SDLK_KP_3: return o2 + 7;

    case SDLK_KP_DIVIDE  : return '/';
    case SDLK_KP_MULTIPLY: return '*';
    case SDLK_KP_PLUS    : return '+';
    case SDLK_KP_MINUS   : return '-';
    case SDLK_KP_ENTER   : return 13;
  }

  return 0;
}



void Render(void)
{
  SDL_SetRenderTarget(MyRenderer, 0);

  SDL_Rect dest; GetMyRenderDest(&dest);
  SDL_RenderCopy(MyRenderer, MyBackTexture, 0, &dest);

  SDL_RenderPresent(MyRenderer);
}



void SleepMS(unsigned int ms)
{
#ifndef COMPILE_SDL
    emscripten_sleep(ms);
#else
    SDL_Delay(ms);
#endif
}



int GetInput(unsigned int ms)
{
  unsigned int start_ms = SDL_GetTicks();
  int ch = 0;

  do
  {
    SDL_Event event;

    SleepMS(5);

    while (SDL_PollEvent(&event)) switch (event.type)
    {
#ifdef COMPILE_SDL
      case SDL_QUIT:
        exit(0);
      break;

      case SDL_WINDOWEVENT:
        switch (event.window.event)
        {
          case SDL_WINDOWEVENT_MOVED:
          case SDL_WINDOWEVENT_RESTORED:
          case SDL_WINDOWEVENT_FOCUS_GAINED:
            Render();
          break;
        }
      break;
#endif

      case SDL_KEYDOWN:
      {
        int sym = event.key.keysym.sym;
        int shift = event.key.keysym.mod & KMOD_SHIFT;

#ifdef COMPILE_SDL
        if (sym == SDLK_F11)
        {
          static int fullscreen = 0;
          fullscreen ^= 1;
          SDL_SetWindowFullscreen(MyWindow, fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
        }
        else
#endif

#ifndef COMPILE_SDL
        int ctrl = event.key.keysym.mod & KMOD_CTRL;
        //ignore browser zoom keys
        if (ctrl && (sym == SDLK_MINUS || sym == SDLK_EQUALS || sym == SDLK_KP_PLUS || sym == SDLK_KP_MINUS)) {}
        else
#endif

        ch = InputRoutine(sym, shift);
      }
      break;

    }
  } while (SDL_GetTicks() - start_ms < ms && !ch);

  return ch;
}



void ClearScreen(void)
{
  SDL_SetRenderTarget(MyRenderer, MyBackTexture);

  SDL_SetRenderDrawColor(MyRenderer, 0, 0, 0, 255);
  SDL_RenderClear(MyRenderer);
}



#define NUM_ATTR  16

typedef struct {int r, g, b;} ATTR_RGB;

ATTR_RGB attr_rgb[NUM_ATTR] =
{
  {  0,   0,   0}, //black
  { 99,  99, 177}, //blue
  { 29, 142,  29}, //green
  { 29, 142, 142}, //cyan
  {172,  89,  89}, //red
  {172,  89, 172}, //magenta
  {177, 138,  99}, //brown
  {192, 192, 192}, //grey
  {128, 128, 128}, //dgrey
  { 99,  99, 255}, //lblue
  {  0, 255,   0}, //lgreen
  {  0, 255, 255}, //lcyan
  {255,   0,   0}, //lred
  {255,   0, 255}, //lmagenta
  {255, 255,   0}, //yellow
  {255, 255, 255}  //white
};



void PutFont(int ch, int x, int y)
{
  int attr = ch>>8;

  ch &= 127;
  if (ch < ' ' || ch > '~') ch = '?';

  SDL_Rect src  = {.x = CHAR_W*(ch-32), .y = 0       , .w = CHAR_W, .h = CHAR_H};
  SDL_Rect dest = {.x = CHAR_W*x      , .y = CHAR_H*y, .w = CHAR_W, .h = CHAR_H};

  SDL_SetRenderTarget(MyRenderer, MyBackTexture);

  if (attr >= 16)
  {
    SDL_SetRenderDrawColor(MyRenderer, attr_rgb[(attr>>4)&15].r, attr_rgb[(attr>>4)&15].g, attr_rgb[(attr>>4)&15].b, 255);
    SDL_RenderFillRect(MyRenderer, &dest);

    SDL_SetTextureColorMod(MyFontTexture, attr_rgb[attr&15].r, attr_rgb[attr&15].g, attr_rgb[attr&15].b);
    SDL_SetTextureBlendMode(MyFontTexture, SDL_BLENDMODE_BLEND);
    SDL_RenderCopy(MyRenderer, MyFontTexture, &src, &dest);
  }
  else if (ch == 32)
  {
    SDL_SetRenderDrawColor(MyRenderer, 0, 0, 0, 255);
    SDL_RenderFillRect(MyRenderer, &dest);
  }
  else
  {
    SDL_SetTextureColorMod(MyFontTexture, attr_rgb[attr].r, attr_rgb[attr].g, attr_rgb[attr].b);
    SDL_SetTextureBlendMode(MyFontTexture, SDL_BLENDMODE_NONE);
    SDL_RenderCopy(MyRenderer, MyFontTexture, &src, &dest);
  }
}



//rect must be <= 32x32
void ReverseRect(int x, int y, int w, int h)
{
  SDL_Rect dest = {.x = x, .y = y, .w = w, .h = h};
  unsigned char p[4*32*32], *q = p;
  int i, j;

  SDL_SetRenderTarget(MyRenderer, MyBackTexture);

  SDL_RenderReadPixels(MyRenderer, &dest, SDL_PIXELFORMAT_RGBA8888, p, 4*32);

  for (j=0; j<h; j++, q += 4*32 - 4*w)
  for (i=0; i<w; i++, q += 4)
  {
    int r = q[3] ^ 255;
    int g = q[2] ^ 255;
    int b = q[1] ^ 255;

    SDL_SetRenderDrawColor(MyRenderer, r, g, b, 255);
    SDL_RenderDrawPoint(MyRenderer, x+i, y+j);
  }
}



void PutCursor(int x, int y, int h)
{
  ReverseRect(CHAR_W*x, CHAR_H*y + CHAR_H-h, CHAR_W, h);
}
//****************************************************************************



//****************************************************************************
void InitFont(void)
{
  SDL_Surface *surface = SDL_CreateRGBSurfaceFrom((void *)FontData, CHAR_W*NUM_FONT_CHARS, CHAR_H, 4*8, 4*CHAR_W*NUM_FONT_CHARS,
                                                  0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000);
  MyFontTexture = SDL_CreateTextureFromSurface(MyRenderer, surface);
  SDL_FreeSurface(surface);
}



void InitInterface(void)
{
  SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER);

  MyWindow = SDL_CreateWindow(MY_WINDOW_TITLE, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                              CLIENT_W, CLIENT_H, 0);

  MyRenderer = SDL_CreateRenderer(MyWindow, -1, 0); //SDL_RENDERER_SOFTWARE
  
  MyBackTexture = SDL_CreateTexture(MyRenderer, SDL_PIXELFORMAT_RGB888, SDL_TEXTUREACCESS_TARGET, CLIENT_W, CLIENT_H);

  ClearScreen();
  Render();
  
  InitFont();
}
//****************************************************************************



//############################################################################
void wrapped_main(void);



int main(int argc __attribute__((unused)), char **argv __attribute__((unused)) )
{
#ifndef COMPILE_SDL
  IDBFS_init();
#endif

  InitInterface();

  wrapped_main();

  return 0; //not reached
}
//############################################################################
