#include <stdio.h>
#include <stdlib.h>
#include <string.h>



struct text_file_struct {const char *name, *filename;} text_file[23] =
{
  { "Help1",      "help1.txt"   },
  { "Help2",      "help2.txt"   },
  { "Help3",      "help3.txt"   },
  { "Help4",      "help4.txt"   },
  { "Help5",      "help5.txt"   },
  { "Help6",      "help6.txt"   },
  { "Help7",      "help7.txt"   },
  { "Help8",      "help8.txt"   },
  { "Help9",      "help9.txt"   },
  { "Help10",     "help10.txt"  },
  { "Help11",     "help11.txt"  },
  { "Help12",     "help12.txt"  },
  { "Help13",     "help13.txt"  },
  { "License",    "license.txt" },
  { "Motd",       "motd.txt"    },
  { "HiDefault",  "omega.hi"    },
  { "LogDefault", "omega.log"   },
  { "Intro",      "intro.txt"   },
  { "Abyss",      "abyss.txt"   },
  { "Scroll1",    "scroll1.txt" },
  { "Scroll2",    "scroll2.txt" },
  { "Scroll3",    "scroll3.txt" },
  { "Scroll4",    "scroll4.txt" },
};



//*****************************************************************************
void displayfile(int index)
{
  FILE *f;
  int ch;

  f = fopen(text_file[index].filename, "r"); if (f == 0) return;
  ch = fgetc(f);
  printf("const char *%sText =\n  \"", text_file[index].name);
  while (ch != EOF)
  {
    if (ch == '\n') printf("\\n\"\n  \"");
    else
    {
      if (ch == '\\' || ch == '\"' || ch == '\'' || ch == '\?') putchar('\\');
      putchar(ch);
    }
    ch = fgetc(f);
  }
  printf("\";\n\n");
  fclose(f);
}    
//*****************************************************************************



//#############################################################################
int main(int argc, char **argv)
{
  int i;

  for (i=0; i<23; i++) displayfile(i);

  return 0;
}
//#############################################################################
